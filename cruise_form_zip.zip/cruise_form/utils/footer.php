<?php

echo "<hr>";
echo "Copyright 2023 - ABC Company, LLC";